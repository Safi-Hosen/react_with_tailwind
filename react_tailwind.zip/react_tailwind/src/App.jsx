// import { useState } from 'react'
// import './App.css'
import Billu from './new.jsx'


function App() {
  return (
    <>
      <h1 class="text-3xl font-bold underline text-red-500 p-3 bg-black">Hello world!</h1>
      <Billu/>
    </>
  );
}

export default App;
