function Billu() {
    return (
        <>
        <div className="font-bold text-3xl text-white p-3 bg-blue-500 underline mt-1 ">This is a new billu</div>
        </>
    )
}

export default Billu;